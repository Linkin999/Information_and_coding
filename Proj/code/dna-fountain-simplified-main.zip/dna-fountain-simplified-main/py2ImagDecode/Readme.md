# DNA-Fountain 图片解码


## 总览



`decode.py`用于解码恢复成原图片。


---

## 用法

> 先决条件

1. 安装 python2
2. 安装 numpy,reedsolo,tqdm。一种安装方式：`$pip2 install numpy reedsolo tqdm`
